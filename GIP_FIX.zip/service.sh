#!/system/bin/sh
DIR=/data/misc/com.richardluo.globalIconPack

# The Xposed framework relabels its own data after boot, so wait for it to appear
# and let its policy patch settle before touching anything.
i=0
while [ ! -d /data/adb/lspd ] && [ $i -lt 60 ]; do
  sleep 1
  i=$((i + 1))
done
sleep 5

# chcon accepts a type the running policy does not define and leaves the file with an
# unresolvable label, which denies every domain instead of just failing. Frameworks also
# disagree on the type name, so pick the first one this policy actually knows. The type
# used before is tried first so setups it already works on keep the same label.
valid_ctx() { echo -n "$1" > /sys/fs/selinux/context 2>/dev/null; }

CTX=
for t in gip_file lsposed_file xposed_data magisk_file; do
  if valid_ctx "u:object_r:$t:s0"; then
    CTX="u:object_r:$t:s0"
    break
  fi
done

mkdir -p "$DIR"
chown 9999:9999 "$DIR" && chmod 0777 "$DIR"
[ -n "$CTX" ] && chcon "$CTX" "$DIR"

for f in "$DIR"/*; do
  [ -e "$f" ] || continue
  chown 9999:9999 "$f" && chmod 0666 "$f"
  [ -n "$CTX" ] && chcon "$CTX" "$f"
done

echo "$(date) ctx=${CTX:-none}" >> /data/local/tmp/globaliconpack-fix.log
